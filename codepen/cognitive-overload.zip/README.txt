A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/pEgmXa.

 Working on a header for a blog post.